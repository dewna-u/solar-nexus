import React, { useEffect, useState } from "react";
import { Container, Typography, Paper, CircularProgress } from "@mui/material";

const Profile = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Function to fetch user profile
  const fetchUserProfile = async () => {
    const token = localStorage.getItem("token"); // Get token from localStorage

    try {
      const response = await fetch("http://localhost:5000/api/auth/profile", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`, // Include token in header
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Failed to fetch profile");

      return data; // Return user data
    } catch (err) {
      throw new Error(err.message);
    }
  };

  // Fetch user profile on component mount
  useEffect(() => {
    const getUserData = async () => {
      try {
        const userData = await fetchUserProfile();
        setUser(userData); // Store user data in state
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    getUserData();
  }, []);

  if (loading) return <CircularProgress />;
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} style={{ padding: "20px", marginTop: "20px" }}>
        <Typography variant="h4" gutterBottom>User Profile</Typography>
        <Typography variant="h6"><strong>First Name:</strong> {user.firstname}</Typography>
        <Typography variant="h6"><strong>Last Name:</strong> {user.lastname}</Typography>
        <Typography variant="h6"><strong>Address:</strong> {user.address}</Typography>
        <Typography variant="h6"><strong>Mobile:</strong> {user.mobilenumber}</Typography>
        <Typography variant="h6"><strong>Email:</strong> {user.email}</Typography>
      </Paper>
    </Container>
  );
};

export default Profile;
