import React from "react";
import { AppBar, Toolbar, Typography, Button, Container, Grid, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import SolarPowerIcon from "@mui/icons-material/SolarPower";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PaymentIcon from "@mui/icons-material/Payment";
import GroupIcon from "@mui/icons-material/Group";
import FeedbackIcon from "@mui/icons-material/Feedback";
import ContactMailIcon from "@mui/icons-material/ContactMail";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        backgroundImage: "url('/assets/solar-bg.jpg')", 
        backgroundSize: "cover",
        backgroundPosition: "center",
        height: "100vh",
        color: "white",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Navbar */}
      <AppBar position="static" sx={{ backgroundColor: "rgba(0, 0, 0, 0.7)" }}>
        <Toolbar>
          <SolarPowerIcon sx={{ fontSize: 40, mr: 1, color: "#ff9800" }} />
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Solar Nexus
          </Typography>
          <Button color="inherit" onClick={() => navigate("/login")}>Login</Button>
          <Button color="inherit" onClick={() => navigate("/register")}>Register</Button>
        </Toolbar>
      </AppBar>

      {/* Main Content */}
      <Container sx={{ flexGrow: 1, display: "flex", flexDirection: "column", justifyContent: "center", textAlign: "center" }}>
        <Typography variant="h3" gutterBottom fontWeight="bold">
          Welcome to Solar Nexus
        </Typography>
        <Typography variant="h6" gutterBottom>
          Navigate to different sections of the Solar Monitoring System
        </Typography>

        {/* Buttons Grid */}
        <Grid container spacing={3} justifyContent="center" mt={3}>
          {[
            { label: "Solar Inputs", icon: <SolarPowerIcon />, route: "/SolarInputs" },
            { label: "Solar Monitor", icon: <DashboardIcon />, route: "/MonitoringDashboard" },
            { label: "Payment Page", icon: <PaymentIcon />, route: "/PaymentPage" },
            { label: "Membership Page", icon: <GroupIcon />, route: "/MembershipPage" },
            { label: "Feedback", icon: <FeedbackIcon />, route: "/Feedback" },
            { label: "Contact", icon: <ContactMailIcon />, route: "/Contact" },
            { label: "Admin Feedback", icon: <AdminPanelSettingsIcon />, route: "/FeedbackAdmin" },
          ].map((item, index) => (
            <Grid item key={index}>
              <Button
                variant="contained"
                color="warning"
                size="large"
                sx={{ 
                  minWidth: 200, 
                  minHeight: 60, 
                  fontSize: "1rem", 
                  fontWeight: "bold", 
                  display: "flex", 
                  flexDirection: "column",
                  gap: 1
                }}
                onClick={() => navigate(item.route)}
                startIcon={item.icon}
              >
                {item.label}
              </Button>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default HomePage;
