const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const nodemailer = require("nodemailer");

let otpStorage = {}; // Temporary storage for OTPs

// Register a new user
exports.registerUser = async (req, res) => {
  try {
    const { firstname, lastname, address, mobilenumber, email, password } = req.body;

    if (!firstname || !lastname || !address || !mobilenumber || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      firstname,
      lastname,
      address,
      mobilenumber,
      email,
      password: hashedPassword,
    });

    await newUser.save();
    res.status(201).json({ message: "User registered successfully!" });
  } catch (error) {
    console.error("🔥 Server Error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Login user
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || "defaultsecret",
      { expiresIn: "1h" }
    );

    res.status(200).json({ message: "Login successful", token });
  } catch (error) {
    console.error("🔥 Error logging in:", error.message);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get user profile
exports.getUserProfile = async (req, res) => {
  try {
    // Ensure that token verification is done by middleware
    if (!req.user || !req.user.userId) {
      return res.status(401).json({ message: "Unauthorized: Invalid token" });
    }

    const user = await User.findById(req.user.userId).select("-password");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json(user);
  } catch (error) {
    console.error("🔥 Error fetching user profile:", error.message);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Send OTP for Password Reset
exports.sendOTP = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ message: "Email not registered." });

    const otp = Math.floor(100000 + Math.random() * 900000);
    otpStorage[email] = { otp, expiresAt: Date.now() + 300000 }; // OTP expires in 5 mins

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: "your-email@gmail.com", pass: "your-password" }, // Make sure to replace this
    });

    await transporter.sendMail({
      from: "your-email@gmail.com", // Update to your email
      to: email,
      subject: "Password Reset OTP",
      text: `Your OTP is ${otp}. It will expire in 5 minutes.`,
    });

    res.json({ message: "OTP sent to email." });
  } catch (error) {
    console.error("🔥 Error sending OTP:", error.message);
    res.status(500).json({ message: "Error sending OTP.", error: error.message });
  }
};

// Verify OTP
exports.verifyOTP = async (req, res) => {
  const { email, otp } = req.body;

  if (!otpStorage[email] || otpStorage[email].otp != otp) {
    return res.status(400).json({ message: "Invalid or expired OTP." });
  }

  delete otpStorage[email];
  res.json({ message: "OTP verified successfully." });
};

// Reset Password
exports.resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ message: "User not found." });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.json({ message: "Password reset successfully. You can now log in." });
  } catch (error) {
    console.error("🔥 Error resetting password:", error.message);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
