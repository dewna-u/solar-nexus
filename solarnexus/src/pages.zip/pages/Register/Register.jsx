import React, { useState } from "react";
import { TextField, Button, Container, Typography, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Register = () => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    address: "",
    mobilenumber: "",
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Validation functions
  const isValidEmail = (email) => /\S+@\S+\.\S+/.test(email);
  const isValidPassword = (password) => password.length >= 6;
  const isValidMobile = (mobilenumber) => /^[0-9]{10}$/.test(mobilenumber);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!isValidEmail(formData.email)) {
      setError("Please enter a valid email address.");
      return;
    }

    if (!isValidPassword(formData.password)) {
      setError("Password must be at least 6 characters long.");
      return;
    }

    if (!isValidMobile(formData.mobilenumber)) {
      setError("Mobile number must be 10 digits long.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/auth/register", formData);

      if (response.status === 201) {
        alert("Registration successful!");
        navigate("/login");
      }
    } catch (err) {
      console.error("🔥 Registration Error:", err.response?.data?.message || err.message);
      setError(err.response?.data?.message || "Server error, please try again.");
    }
  };

  return (
    <Container maxWidth="sm">
      <Box mt={10} p={4} boxShadow={3} borderRadius={2} textAlign="center">
        <Typography variant="h4" gutterBottom>
          Create an Account
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField label="First Name" name="firstname" variant="outlined" fullWidth margin="normal" value={formData.firstname} onChange={handleChange} required />
          <TextField label="Last Name" name="lastname" variant="outlined" fullWidth margin="normal" value={formData.lastname} onChange={handleChange} required />
          <TextField label="Address" name="address" variant="outlined" fullWidth margin="normal" value={formData.address} onChange={handleChange} required />
          <TextField label="Mobile Number" name="mobilenumber" variant="outlined" fullWidth margin="normal" value={formData.mobilenumber} onChange={handleChange} required />
          <TextField label="Email" name="email" variant="outlined" fullWidth margin="normal" value={formData.email} onChange={handleChange} required />
          <TextField label="Password" name="password" type="password" variant="outlined" fullWidth margin="normal" value={formData.password} onChange={handleChange} required />
          
          {error && <Typography color="error" variant="body2">{error}</Typography>}
          
          <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
            Register
          </Button>
        </form>
        
        <Typography mt={2}>
          Already have an account?{" "}
          <Button onClick={() => navigate("/login")} color="primary">
            LOGIN HERE
          </Button>
        </Typography>
      </Box>
    </Container>
  );
};

export default Register;
